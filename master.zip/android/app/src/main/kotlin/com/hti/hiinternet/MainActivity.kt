package com.hti.hiinternet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
