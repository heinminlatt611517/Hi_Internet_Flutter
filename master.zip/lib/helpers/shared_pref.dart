import 'dart:convert';

import 'package:hiinternet/login_screen/login_response.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/foundation.dart';


class SharedPref with ChangeNotifier{

  static const token = 'token';
  static const account ='account';
  static const payment ='payment';
  static const user_id ='user_id';
  static const user_phone ='user_phone';
  static const home ='home';
  static const complain_ticket ='complain_ticket';
  static const complain_category ='complain_category';
  static const language_status ='language_status';



 static Future<bool> setData(String key,String value) async{
   SharedPreferences shp = await SharedPreferences.getInstance();
   return shp.setString(key, value);
 }

 
 static Future<String> getData({@required String key})  async {
   SharedPreferences shp = await SharedPreferences.getInstance();
   return shp.getString(key);
 }




 static void clear() async{
   SharedPreferences shp = await SharedPreferences.getInstance();
   shp.clear();
 }

}