import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_neumorphic/flutter_neumorphic.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:hiinternet/helpers/response_vo.dart';
import 'package:hiinternet/helpers/shared_pref.dart';
import 'package:hiinternet/login_screen/login_bloc.dart';
import 'package:hiinternet/login_screen/login_response.dart';
import 'package:hiinternet/screens/account_screen/account_screen.dart';
import 'package:hiinternet/screens/home_screen/home_screen.dart';
import 'package:hiinternet/screens/notification_screen/notification_screen.dart';
import 'package:hiinternet/screens/payment_screen/payment_screen.dart';
import 'package:ff_navigation_bar/ff_navigation_bar.dart';
import 'dart:math';

import 'package:hiinternet/screens/service_history_screen/service_history_screen.dart';

class TabScreens extends StatefulWidget {
  static const routeName = '/tab_screen';

  @override
  _TabScreenState createState() => _TabScreenState();
}

class _TabScreenState extends State<TabScreens>
    with SingleTickerProviderStateMixin {
  List<Map<String, Object>> _pages;
  var _scaffoldKey = GlobalKey<ScaffoldState>();

  bool isOpened = false;
  AnimationController _animationController;
  Animation<Color> _buttonColor;
  Animation<double> _animateIcon;
  Animation<double> _translateButton;
  Curve _curve = Curves.easeOut;
  double _fabHeight = 56.0;

  bool _validate = false;
  var userIdController = TextEditingController();

  final _loginBloc = LoginBloc();

  @override
  initState() {
    _animationController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 500))
          ..addListener(() {
            setState(() {});
          });
    _animateIcon =
        Tween<double>(begin: 0.0, end: 1.0).animate(_animationController);
    _buttonColor = ColorTween(
      begin: Colors.blue,
      end: Colors.red,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Interval(
        0.00,
        1.00,
        curve: Curves.linear,
      ),
    ));
    _translateButton = Tween<double>(
      begin: _fabHeight,
      end: -14.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Interval(
        0.0,
        0.75,
        curve: _curve,
      ),
    ));

    _pages = [
      {
        'page': HomeScreen(),
        'title': 'Home',
      },
      {
        'page': PaymentScreen(),
        'title': 'Payment',
      },
      {
        'page': NotificationScreen(),
        'title': 'Notification',
      },
      {
        'page': AccountScreen(),
        'title': 'My Account',
      },
    ];

    super.initState();
  }

  int _selectedPageIndex = 0;

  void _selectPage(int index) {
    SharedPref.getData(key: SharedPref.token).then((value) {
      if (value != null && value.toString() != 'null') {
        print(json.decode(value));
        setState(() {
          _selectedPageIndex = index;
        });
      } else {
        showUserLoginDialog(context);
      }
    });
  }

  animate() {
    if (!isOpened) {
      _animationController.forward();
    } else {
      _animationController.reverse();
    }
    isOpened = !isOpened;
  }

  Widget add() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          margin: EdgeInsets.only(right: 10),
          child: FloatingActionButton(
            onPressed: null,
            tooltip: 'Add',
            child: Icon(Icons.phone),
          ),
        ),
        Text('Call Us'),
      ],
    );
  }

  Widget image() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          margin: EdgeInsets.only(right: 10),
          child: FloatingActionButton(
            onPressed: null,
            tooltip: 'Add',
            child: Icon(Icons.error_outline),
          ),
        ),
        Text('Service Issue'),
      ],
    );
  }

  Widget inbox() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          margin: EdgeInsets.only(right: 10),
          child: FloatingActionButton(
            onPressed: null,
            tooltip: 'Add',
            backgroundColor: Colors.black,
            child: Icon(Icons.history_edu_rounded),
          ),
        ),
        Text('Service History'),
      ],
    );
  }

  Widget toggle() {
    return Container(
      child: FloatingActionButton(
        backgroundColor: Colors.white,
        onPressed: animate,
        tooltip: 'Toggle',
        child: Image.asset('assets/images/floating_icon.png'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      body: _pages[_selectedPageIndex]['page'],
      bottomNavigationBar: FFNavigationBar(
        theme: FFNavigationBarTheme(
          barBackgroundColor: Colors.white,
          selectedItemBorderColor: Colors.transparent,
          selectedItemBackgroundColor: Colors.green,
          selectedItemIconColor: Colors.white,
          selectedItemLabelColor: Colors.black,
          unselectedItemBackgroundColor: Colors.white,
          showSelectedItemShadow: false,
          barHeight: 70,
        ),
        onSelectTab: _selectPage,
        items: [
          FFNavigationBarItem(
            iconData: Icons.home,
            label: 'Home',
            selectedBackgroundColor: Theme.of(context).primaryColor,
          ),
          FFNavigationBarItem(
            selectedBackgroundColor: Theme.of(context).primaryColor,
            iconData: Icons.payment,
            label: 'Payment',
          ),
          FFNavigationBarItem(
            selectedBackgroundColor: Theme.of(context).primaryColor,
            iconData: Icons.notifications,
            label: 'Notification',
          ),
          FFNavigationBarItem(
            selectedBackgroundColor: Theme.of(context).primaryColor,
            iconData: Icons.account_circle,
            label: 'My Account',
          ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(
          backgroundColor: Colors.white,
          child: Image.asset('assets/images/floating_icon.png'),
          onPressed: () => Navigator.pushNamed(context, ServiceHistoryScreen.routeName)),
    );

    // floatingActionButton: Container(
    //   margin: EdgeInsets.only(bottom: 50),
    //   child: Column(
    //     mainAxisAlignment: MainAxisAlignment.end,
    //     children: [
    //     Transform(
    //       transform: Matrix4.translationValues(
    //         0.0,
    //         _translateButton.value * 3.0,
    //         0.0,
    //       ),
    //       child: add(),
    //     ),
    //     Transform(
    //       transform: Matrix4.translationValues(
    //         0.0,
    //         _translateButton.value * 2.0,
    //         0.0,
    //       ),
    //       child: image(),
    //     ),
    //     Transform(
    //       transform: Matrix4.translationValues(
    //         0.0,
    //         _translateButton.value,
    //         0.0,
    //       ),
    //       child: inbox(),
    //     ),
    //     toggle(),
    //   ],),
    // ),
  }

  void showContainer(BuildContext context) {
    Center(
      child: Container(
        height: 50,
        width: 50,
        color: Colors.black,
      ),
    );
  }

  void showUserLoginDialog(BuildContext context) {
    showDialog(
        context: context,
        builder: (ctx) => Center(
              child: Container(
                height: 300,
                width: 250,
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: EdgeInsets.all(4),
                child: Material(
                  child: Container(
                    color: Colors.white,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            FlatButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                child: Icon(Icons.cancel_presentation)),
                          ],
                        ),
                        Text(
                          'Please sign in to unlock all\naccount features',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontWeight: FontWeight.normal,
                              fontSize: 14,
                              decoration: TextDecoration.none,
                              color: Colors.grey),
                        ),
                        Container(
                          width: 80,
                          child: TextField(
                            controller: userIdController,
                            textAlign: TextAlign.center,
                            decoration: InputDecoration(
                                contentPadding: EdgeInsets.only(top: 15),
                                hintText: 'User ID',
                                errorText: _validate ? 'Empty' : null,
                                hintStyle: TextStyle(fontSize: 15)),
                          ),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        loginButton(context),
                        SizedBox(
                          height: 5,
                        ),
                        Column(
                          children: [
                            Text(
                              'need help?',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.normal,
                                  color: Colors.black),
                            ),
                            Container(
                                width: 70,
                                alignment: Alignment.center,
                                child: Divider(
                                  height: 2,
                                  color: Colors.black,
                                )),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ));
  }

  void login() {
    setState(() {
      userIdController.text.isEmpty ? _validate = true : _validate = false;
      return;
    });

    Map<String, String> map = {
      'user_id': userIdController.text,
      'app_version': '1',
    };

    _loginBloc.login(map);
  }

  Widget loginButton(BuildContext context) {
    return StreamBuilder<ResponseVO>(
        stream: _loginBloc.loginStream(),
        initialData: ResponseVO(),
        builder: (context, snapshot) {
          ResponseVO resp = snapshot.data;
          if (resp.message == MsgState.loading) {
            return Center(
              child: Container(
                margin: EdgeInsets.all(10),
                child: Neumorphic(
                  style: NeumorphicStyle(
                    color: Colors.white,
                    shape: NeumorphicShape.concave,
                    boxShape: NeumorphicBoxShape.circle(),
                    depth: -3,
                  ),
                  child: CircularProgressIndicator(
                    strokeWidth: 3,
                  ),
                ),
              ),
            );
          } else if (resp.message == MsgState.error) {
            return Center(
              child: Text('Something wrong,try again...'),
            );
          } else if (resp.message == MsgState.success) {
            Navigator.of(context).pop();
            return Container();
          } else {
            return Container(
              margin: EdgeInsets.only(left: 50, right: 50),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(35),
                child: RaisedButton(
                  color: Colors.blue,
                  onPressed: login,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.login),
                      SizedBox(
                        width: 5,
                      ),
                      Text(
                        'sign in',
                        style: TextStyle(
                            decoration: TextDecoration.none,
                            fontSize: 16,
                            fontWeight: FontWeight.normal,
                            color: Colors.white),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }
        });
  }

  @override
  void dispose() {
    userIdController.dispose();
    _animationController.dispose();
    super.dispose();
  }
}
