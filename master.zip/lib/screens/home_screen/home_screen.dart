import 'package:flutter/material.dart';
import 'package:flutter_neumorphic/flutter_neumorphic.dart';
import 'package:hiinternet/helpers/response_vo.dart';
import 'package:hiinternet/helpers/shared_pref.dart';
import 'package:hiinternet/screens/home_screen/home_bloc.dart';
import 'package:hiinternet/screens/home_screen/home_response.dart';
import 'package:hiinternet/widgets/middle_feature_item.dart';
import 'package:hiinternet/widgets/our_application_item.dart';
import 'package:hiinternet/widgets/top_promotion_item.dart';
import 'package:provider/provider.dart';

class HomeScreen extends StatefulWidget {
  static const routeName = '/home_screen';

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String selected = 'ENG';
  final _homeBloc = HomeBloc();



  @override
  void initState() {
    Map<String, String> map = {
      'user_id': 'u_123',
      'app_version': '1',
    };
    _homeBloc.getHomeData(map);
    super.initState();
  }

  @override
  void didChangeDependencies() {
    SharedPref.getData(key: SharedPref.language_status).then((value) {
      if (value != null && value.toString() != 'null') {
        if (value == 'ENG') {
          setState(() {
            selected = 'ENG';
          });
        } else {
          setState(() {
            selected = 'မြန်မာ';
          });
        }
      }
    });

    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {


    var size = MediaQuery.of(context).size;

    /*24 is for notification bar on Android*/
    final double itemHeight = (size.height - kToolbarHeight - 24) / 4;
    final double itemWidth = size.width / 2;

    return SingleChildScrollView(
      child: ConstrainedBox(
        constraints:
            BoxConstraints(maxHeight: MediaQuery.of(context).size.height),
        child: Scaffold(
          appBar: AppBar(
            toolbarHeight: 110,
            title: Container(
              width: MediaQuery.of(context).size.width,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    alignment: Alignment.center,
                    padding: EdgeInsets.all(10),
                    margin: EdgeInsets.only(right: 50),
                    width: 100,
                    child: Image.asset(
                      'assets/images/hi_internet_logo.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              Container(
                height: 50,
                width: 80,
                margin: EdgeInsets.only(bottom: 37, right: 30, top: 33),
                padding: EdgeInsets.all(2),
                child: Neumorphic(
                  style: NeumorphicStyle(
                      color: Colors.white,
                      shape: NeumorphicShape.concave,
                      boxShape: NeumorphicBoxShape.roundRect(
                          BorderRadius.circular(12)),
                      depth: -4,
                      lightSource: LightSource.topLeft),
                  child: DropdownButtonFormField<String>(
                    isExpanded: true,
                    value: selected,
                    items: ["မြန်မာ", "ENG"]
                        .map((label) => DropdownMenuItem(
                              child: Text(
                                label,
                                style: TextStyle(fontSize: 12),
                              ),
                              value: label,
                            ))
                        .toList(),
                    onChanged: (value) {
                      setState(() {
                        selected = value;
                        if (selected == 'ENG') {
                          SharedPref.setData(
                              SharedPref.language_status, selected);
                        }
                        if (selected == 'မြန်မာ') {
                          SharedPref.setData(
                              SharedPref.language_status, selected);
                        }
                        print(value);
                      });
                    },
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.only(left: 10, bottom: 12)),
                  ),
                ),
              ),
            ],
          ),
          body: StreamBuilder(
            builder: (context, snapshot) {
              ResponseVO resp = snapshot.data;
              if (resp.message == MsgState.loading) {
                return Center(
                  child: Container(
                      margin: EdgeInsets.only(
                        top: 10,
                      ),
                      child: CircularProgressIndicator()),
                );
              } else if (resp.message == MsgState.error) {
                print(snapshot.toString());
                return Center(
                  child: Text('Something wrong,try again...'),
                );
              } else {
                HomeDataVO data = resp.data;
                List<UpImagesVO> upImageLists = data.upImages;
                List<MiddleImagesVO> middleImageLists = data.middleImages;
                List<DownImagesVO> downImageLists = data.downImages;
                print(upImageLists.length);

                return Column(
                  children: [
                    TopPromotionItems(upImageLists),
                    SizedBox(
                      height: 10,
                    ),
                    Center(
                      child: Text(
                        'Feature',
                        style: TextStyle(
                            fontSize: 17, fontWeight: FontWeight.bold),
                      ),
                    ),
                    MiddleFeatureItems(middleImageLists),
                    SizedBox(
                      height: 10,
                    ),
                    Center(
                      child: Text(
                        'Our Applications',
                        style: TextStyle(
                            fontSize: 17, fontWeight: FontWeight.bold),
                      ),
                    ),
                    Expanded(
                      child: GridView(
                        padding: const EdgeInsets.all(10),
                        children: downImageLists
                            .map((imgData) => OurApplicationItems(
                                imgData.imageV1,
                                imgData.title,
                                imgData.description,
                                imgData.backgroundColor,
                                imgData.titleTextColor,
                                imgData.descriptionTextColor))
                            .toList(),
                        gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                            maxCrossAxisExtent: 200,
                            mainAxisSpacing: 20,
                            crossAxisSpacing: 20,
                            childAspectRatio: (itemWidth / itemHeight)),
                      ),
                    ),
                  ],
                );
              }
            },
            stream: _homeBloc.homeStream(),
            initialData: ResponseVO(message: MsgState.loading),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _homeBloc.dispose();
    super.dispose();
  }
}
