import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_neumorphic/flutter_neumorphic.dart';
import 'package:hiinternet/helpers/response_vo.dart';
import 'package:hiinternet/helpers/shared_pref.dart';
import 'package:hiinternet/screens/payment_screen/payment_response.dart';
import 'package:hiinternet/screens/payment_screen/payment_bloc.dart';
import 'package:hiinternet/widgets/payment_item.dart';

class PaymentScreen extends StatefulWidget {
  static const routeName = '/payment_screen';

  @override
  _PaymentScreenState createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {

  String selected = 'ENG';

  var allPayment = false;
  var paidPayment = false;
  var unPaidPayment = false;
  var userId;

  final _paymentBloc = PaymentBloc();

  @override
  void initState() {

    SharedPref.getData(key: SharedPref.user_id).then((value) {
      if (value != null && value.toString() != 'null') {
         userId = json.decode(value).toString();

         Map<String, String> map = {
           'user_id': userId,
           'app_version': '1',
         };

         _paymentBloc.getPayment(map);
      }
    });



    super.initState();
  }


  @override
  void didChangeDependencies() {
    allPayment = true;
    paidPayment = false;
    unPaidPayment = false;

    SharedPref.getData(key: SharedPref.language_status).then((value) {
      if(value!=null && value.toString() != 'null'){
        if(value == 'ENG'){
          setState(() {
            selected = 'ENG';
          });
        }
        else{
          setState(() {
            selected = 'မြန်မာ';
          });
        }
      }
    });

    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {

    return SingleChildScrollView(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height),
        child: Scaffold(
          appBar: AppBar(
            toolbarHeight: 110,
            title: Container(
              width: MediaQuery.of(context).size.width,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(alignment: Alignment.center,
                    padding: EdgeInsets.all(10),
                    margin: EdgeInsets.only(right: 50),
                    width: 100,
                    child: Image.asset(
                      'assets/images/hi_internet_logo.png',
                      fit: BoxFit.cover,
                    ),
                  ),

                ],
              ),
            ),
            actions: [
              Container(
                height: 50,
                width: 80,
                margin: EdgeInsets.only(bottom: 37,right: 30,top: 33),
                padding: EdgeInsets.all(2),
                child: Neumorphic(
                  style: NeumorphicStyle(
                    color: Colors.white,
                      shape: NeumorphicShape.concave,
                      boxShape: NeumorphicBoxShape.roundRect(BorderRadius.circular(12)),
                      depth: -4,
                      lightSource: LightSource.topLeft
                  ),
                  child: DropdownButtonFormField<String>(
                    isExpanded: true,
                    value: selected,
                    items: ["မြန်မာ","ENG"]
                        .map((label) => DropdownMenuItem(
                      child: Text(label,style: TextStyle(fontSize: 12),),
                      value: label,
                    ))
                        .toList(),
                    onChanged: (value) {
                      setState(() {
                        selected = value;
                        if(selected == 'ENG'){
                          SharedPref.setData(SharedPref.language_status, selected);
                        }
                        if(selected == 'မြန်မာ'){
                          SharedPref.setData(SharedPref.language_status, selected);
                        }
                        print(value);
                      });
                    },
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.only(left: 10,bottom: 12)
                    ),
                  ),
                ),
              ),
            ],
          ),
          body: Column(
            children: [
              Container(
                height: 80,
                color: Colors.blueGrey,
                padding: EdgeInsets.all(20),
                child: GestureDetector(
                  onTap: () {},
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(15),
                    child: Container(
                      color: Colors.white,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.payment),
                          Text('Available Payment Options'),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 15,
              ),
              Text(
                'Payment',
                style: TextStyle(
                    color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18),
              ),
              SizedBox(
                height: 15,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 30,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: ActionChip(
                        backgroundColor: allPayment ? Colors.blue : Colors.white,
                        padding: EdgeInsets.only(left: 30, right: 30),
                        label: Text('All'),
                        onPressed: () {
                          setState(() {
                            allPayment = true;
                            paidPayment = false;
                            unPaidPayment = false;
                          });
                        }),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Container(
                    height: 30,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: ActionChip(
                        backgroundColor: paidPayment ? Colors.blue : Colors.white,
                        padding: EdgeInsets.only(left: 25, right: 25),
                        label: Text('Paid'),
                        onPressed: () {
                          setState(() {
                            allPayment = false;
                            paidPayment = true;
                            unPaidPayment = false;
                          });
                        }),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Container(
                    height: 30,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: ActionChip(
                        backgroundColor: unPaidPayment ? Colors.blue : Colors.white,
                        padding: EdgeInsets.only(left: 20, right: 20),
                        label: Text('Unpaid'),
                        onPressed: () {
                          setState(() {
                            allPayment = false;
                            paidPayment = false;
                            unPaidPayment = true;
                          });
                        }),
                  ),
                ],
              ),
              StreamBuilder<ResponseVO>(
                builder: (context, snapshot) {
                  ResponseVO resp = snapshot.data;
                  if (resp.message == MsgState.loading) {
                    return Center(
                      child: Container(
                          margin: EdgeInsets.only(top: 10,),
                          child: CircularProgressIndicator()),
                    );
                  } else if (resp.message == MsgState.error) {
                    return Center(
                      child: Text('Something wrong,try again...'),
                    );
                  } else {
                    List<PaymentVO> list = resp.data;
                   /* List<PaymentVO> paidList = list
                        .where((element) => element.paidStatus == 'Paid')
                        .toList();
                    List<PaymentVO> unPaidList = list
                        .where((element) => element.paidStatus == 'UnPaid')
                        .toList();*/

                    return Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 80),
                        child: ListView.builder(
                          itemBuilder: (ctx, index) {

                            return PaymentItems( list
                                .where((element) =>allPayment ? true : paidPayment ? element.paidStatus == 'Paid' : element.paidStatus == 'UnPaid')
                                .toList()[index]);
                          },
                          itemCount: list
                              .where((element) =>allPayment ? true : paidPayment ? element.paidStatus == 'Paid' : element.paidStatus == 'UnPaid')
                              .toList().length,
                        ),
                      ),
                    );
                  }
                },
                stream: _paymentBloc.paymentStream(),
                initialData: ResponseVO(message: MsgState.loading),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /*

  ListView.builder(
                          itemBuilder: (ctx, index) {
                            if (allPayment) {
                              return PaymentItems(list[index]);
                            }
                            if (paidPayment) {
                              return PaymentItems(paidList[index]);
                            }
                            if (unPaidPayment) {
                              return PaymentItems(unPaidList[index]);
                            }
                            return PaymentItems(list[index]);
                          },
                          itemCount: list.length,
                        ),
   */

  @override
  void dispose() {
    _paymentBloc.dispose();
    super.dispose();
  }

  void _showToast(BuildContext context) {
    final scaffold = Scaffold.maybeOf(context);
    scaffold.showSnackBar(SnackBar(
      content: const Text('SnackBar..'),
    ));
  }
}
