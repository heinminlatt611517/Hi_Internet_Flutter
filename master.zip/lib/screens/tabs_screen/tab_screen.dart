import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_neumorphic/flutter_neumorphic.dart';
import 'package:hiinternet/helpers/response_vo.dart';
import 'package:hiinternet/helpers/shared_pref.dart';
import 'package:hiinternet/login_screen/login_bloc.dart';
import 'package:hiinternet/screens/account_screen/account_screen.dart';
import 'package:hiinternet/screens/home_screen/check_create_user_bloc.dart';
import 'package:hiinternet/screens/home_screen/check_create_user_response.dart';
import 'package:hiinternet/screens/home_screen/home_screen.dart';
import 'package:hiinternet/screens/notification_screen/notification_screen.dart';
import 'package:hiinternet/screens/payment_screen/payment_screen.dart';
import 'package:hiinternet/screens/service_history_screen/service_history_screen.dart';
import 'package:hiinternet/screens/service_issue_screen/service_issue_screen.dart';

class TabScreen extends StatefulWidget {
  static const routeName = '/tab_screen';

  @override
  _TabScreenState createState() => _TabScreenState();
}

class _TabScreenState extends State<TabScreen>
    with SingleTickerProviderStateMixin {
  List<Map<String, Object>> _pages;
  var _scaffoldKey = GlobalKey<ScaffoldState>();

  bool isOpened = false;
  AnimationController _animationController;
  Animation<Color> _buttonColor;
  Animation<double> _animateIcon;
  Animation<double> _translateButton;
  Curve _curve = Curves.easeOut;
  double _fabHeight = 56.0;

  bool _validate = false;
  var userIdController = TextEditingController();

  final _loginBloc = LoginBloc();
  final _checkCreateUserBloc = CheckCreateUserBloc();
  var userId;

  @override
  initState() {
    _animationController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 500))
          ..addListener(() {
            setState(() {});
          });
    _animateIcon =
        Tween<double>(begin: 0.0, end: 1.0).animate(_animationController);
    _buttonColor = ColorTween(
      begin: Colors.blue,
      end: Colors.red,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Interval(
        0.00,
        1.00,
        curve: Curves.linear,
      ),
    ));
    _translateButton = Tween<double>(
      begin: _fabHeight,
      end: -14.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Interval(
        0.0,
        0.75,
        curve: _curve,
      ),
    ));
    // check change
    _pages = [
      {
        'page': HomeScreen(),
        'title': 'Home',
      },
      {
        'page': PaymentScreen(),
        'title': 'Payment',
      },
      {
        'page': NotificationScreen(),
        'title': 'Notification',
      },
      {
        'page': AccountScreen(),
        'title': 'My Account',
      },
      {
        'page': ServiceHistoryScreen(),
        'title': 'Service History',
      },
      {
        'page': ServiceIssueScreen(),
        'title': 'Service Issue',
      },
    ];

    super.initState();
  }

  int _selectedPageIndex = 0;
  int changePageIndex = 0;

  void _selectPage(int index) {
    SharedPref.getData(key: SharedPref.token).then((value) {
      if (value != null && value.toString() != 'null') {
        print(json.decode(value));
        setState(() {
          if (isOpened) {
            _animationController.reverse();
            isOpened = false;
          }

          changePageIndex = 0;
          _selectedPageIndex = index;
        });
      } else {
        showUserLoginDialog(context);
      }
    });
  }

  animate() {
    if (!isOpened) {
      _animationController.forward();
    } else {
      _animationController.reverse();
    }
    isOpened = !isOpened;
  }

  Widget add() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          child: FloatingActionButton(
            heroTag: 'phone',
            onPressed: () {},
            tooltip: 'Add',
            child: Icon(Icons.phone),
          ),
        ),
      ],
    );
  }

  Widget image() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          // child: checkCreateUserStream(context),
          child: FloatingActionButton(
            heroTag: 'service issue',
            onPressed: () {
              SharedPref.getData(key: SharedPref.token).then((value) {
                if (value != null && value.toString() != 'null') {

                  setState(() {
                    changePageIndex = 5;
                    _animationController.reverse();
                    isOpened = false;
                  });

                } else {
                  showUserLoginDialog(context);
                }
              });
            },
            tooltip: 'Add',
            child: Icon(Icons.error_outline),
          ),



        ),
      ],
    );
  }

  Widget inbox() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          child: FloatingActionButton(
            heroTag: 'service history',
            onPressed: () {
              SharedPref.getData(key: SharedPref.token).then((value) {
                if (value != null && value.toString() != 'null') {
                  setState(() {
                    changePageIndex = 4;
                    _animationController.reverse();
                    isOpened = false;
                  });
                } else {
                  showUserLoginDialog(context);
                }
              });
            },
            tooltip: 'Add',
            child: Icon(Icons.history_edu_rounded),
          ),
        ),
      ],
    );
  }

  Widget toggle() {
    return Container(
      child: FloatingActionButton(
        heroTag: 'toggle',
        backgroundColor: Colors.white,
        onPressed: animate,
        tooltip: 'Toggle',
        child: Image.asset('assets/images/floating_icon.png'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      body: changePageIndex == 4 || changePageIndex == 5
          ? _pages[changePageIndex]['page']
          : _pages[_selectedPageIndex]['page'],
      bottomNavigationBar: BottomNavigationBar(
        onTap: _selectPage,
        backgroundColor: Theme.of(context).primaryColor,
        unselectedItemColor: Colors.white,
        selectedItemColor: Theme.of(context).accentColor,
        currentIndex: _selectedPageIndex,
        type: BottomNavigationBarType.fixed,
        items: [
          BottomNavigationBarItem(
              backgroundColor: Theme.of(context).primaryColor,
              icon: Icon(Icons.home),
              title: Text(
                'Home',
              )),
          BottomNavigationBarItem(
              backgroundColor: Theme.of(context).primaryColor,
              icon: Icon(Icons.payment),
              title: Text(
                'Payment',
              )),
          BottomNavigationBarItem(
              backgroundColor: Theme.of(context).primaryColor,
              icon: Icon(Icons.notifications),
              title: Text(
                'Notification',
              )),
          BottomNavigationBarItem(
              backgroundColor: Theme.of(context).primaryColor,
              icon: Icon(Icons.account_circle),
              title: Text(
                'My Account',
              )),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,

      // floatingActionButton: FloatingActionButton(
      //   heroTag: 'main',
      //   backgroundColor: Colors.white,
      //   child: Image.asset('assets/images/floating_icon.png'),
      //   onPressed: () {
      //     setState(() {
      //       changePageIndex = 4;
      //     });
      //   }
      //     ),

      // floatingActionButton: SpeedDial(
      //     icon: Icons.add,
      //     curve: Curves.bounceIn,
      //     children: [
      //       SpeedDialChild(
      //         child: Icon(Icons.accessibility),
      //         label: 'First',
      //         onTap: null,),
      //       SpeedDialChild(
      //         child: Icon(Icons.accessibility),
      //         label: 'Second',
      //         onTap: null,),
      //     ]
      // ),

      floatingActionButton: Container(
        margin: EdgeInsets.only(bottom: 50),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Transform(
              transform: Matrix4.translationValues(
                0.0,
                _translateButton.value * 3.0,
                0.0,
              ),
              child: add(),
            ),
            Transform(
              transform: Matrix4.translationValues(
                0.0,
                _translateButton.value * 2.0,
                0.0,
              ),
              child: image(),
            ),
            Transform(
              transform: Matrix4.translationValues(
                0.0,
                _translateButton.value,
                0.0,
              ),
              child: inbox(),
            ),
            toggle(),
          ],
        ),
      ),
    );
  }

  void showContainer(BuildContext context) {
    Center(
      child: Container(
        height: 50,
        width: 50,
        color: Colors.black,
      ),
    );
  }

  void showUserLoginDialog(BuildContext context) {
    showDialog(
        context: context,
        builder: (ctx) => Center(
              child: Container(
                height: 300,
                width: 250,
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: EdgeInsets.all(4),
                child: Material(
                  child: Container(
                    color: Colors.white,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            FlatButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                child: Icon(Icons.cancel_presentation)),
                          ],
                        ),
                        Text(
                          'Please sign in to unlock all\naccount features',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontWeight: FontWeight.normal,
                              fontSize: 14,
                              decoration: TextDecoration.none,
                              color: Colors.grey),
                        ),
                        Container(
                          width: 80,
                          child: TextField(
                            controller: userIdController,
                            textAlign: TextAlign.center,
                            decoration: InputDecoration(
                                contentPadding: EdgeInsets.only(top: 15),
                                hintText: 'User ID',
                                errorText: _validate ? 'Empty' : null,
                                hintStyle: TextStyle(fontSize: 15)),
                          ),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        loginButton(context),
                        SizedBox(
                          height: 5,
                        ),
                        Column(
                          children: [
                            Text(
                              'need help?',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.normal,
                                  color: Colors.black),
                            ),
                            Container(
                                width: 70,
                                alignment: Alignment.center,
                                child: Divider(
                                  height: 2,
                                  color: Colors.black,
                                )),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ));
  }

  void login() {
    setState(() {
      userIdController.text.isEmpty ? _validate = true : _validate = false;
      return;
    });

    Map<String, String> map = {
      'user_id': userIdController.text,
      'app_version': '1',
    };

    _loginBloc.login(map);
  }

  void checkCreateUser() {
    SharedPref.getData(key: SharedPref.user_id).then((value) {
      if (value != null && value.toString() != 'null') {
        userId = json.decode(value).toString();
        Map<String, String> map = {
          'user_id': userId,
          'app_version': '1',
        };
        _checkCreateUserBloc.checkCreateUser(map);
      }
    });
  }

  // ignore: missing_return
  Widget checkCreateUserStream(BuildContext context) {

    return  StreamBuilder<ResponseVO>(
        initialData: ResponseVO(),
        stream: _checkCreateUserBloc.checkCreateUserStream(),
        builder: (context, snapshot) {

            ResponseVO resp = snapshot.data;

            if (resp.message == MsgState.success) {
              CreateUserResponse createUserResponseVO = resp.data;

              Future.delayed(Duration.zero, () async {
                if(createUserResponseVO.status == 'Success')
                showCheckCreateUserDialog(context,'fail');
              });

              return FloatingActionButton(
                heroTag: 'service issue',
                onPressed: () {
                  SharedPref.getData(key: SharedPref.token).then((value) {
                    if (value != null && value.toString() != 'null') {
                      checkCreateUser();
                    } else {
                      showUserLoginDialog(context);
                    }
                  });
                },
                tooltip: 'Add',
                child: Icon(Icons.error_outline),
              );

            }

            if (resp.message == MsgState.error) {
              return Center(
                child: Text('Something wrong,try again...'),
              );
            }

            else {
              return FloatingActionButton(
                heroTag: 'service issue',
                onPressed: () {
                  SharedPref.getData(key: SharedPref.token).then((value) {
                    if (value != null && value.toString() != 'null') {
                      checkCreateUser();
                    } else {
                      showUserLoginDialog(context);
                    }
                  });
                },
                tooltip: 'Add',
                child: Icon(Icons.error_outline),
              );
            }

        },
      );
  }

  Widget loginButton(BuildContext context) {
    return StreamBuilder<ResponseVO>(
        stream: _loginBloc.loginStream(),
        initialData: ResponseVO(),
        builder: (context, snapshot) {
          ResponseVO resp = snapshot.data;
          if (resp.message == MsgState.loading) {
            return Center(
              child: Container(
                margin: EdgeInsets.all(10),
                child: Neumorphic(
                  style: NeumorphicStyle(
                    color: Colors.white,
                    shape: NeumorphicShape.concave,
                    boxShape: NeumorphicBoxShape.circle(),
                    depth: -3,
                  ),
                  child: CircularProgressIndicator(
                    strokeWidth: 3,
                  ),
                ),
              ),
            );
          } else if (resp.message == MsgState.error) {
            return Center(
              child: Text('Something wrong,try again...'),
            );
          } else if (resp.message == MsgState.success) {
            Navigator.of(context).pop();
            return Container();
          } else {
            return Container(
              margin: EdgeInsets.only(left: 50, right: 50),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(35),
                child: RaisedButton(
                  color: Colors.blue,
                  onPressed: login,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.login),
                      SizedBox(
                        width: 5,
                      ),
                      Text(
                        'sign in',
                        style: TextStyle(
                            decoration: TextDecoration.none,
                            fontSize: 16,
                            fontWeight: FontWeight.normal,
                            color: Colors.white),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }
        });
  }

  void showCheckCreateUserDialog(BuildContext context, String status) {
    showDialog(
        context: context,
        builder: (ctx) => Center(
              child: Container(
                height: 300,
                width: double.infinity,
                margin: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: EdgeInsets.all(4),
                child: Material(
                  child: Container(
                    color: Colors.white,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Center(
                          child: Icon(Icons.error_outline),
                        ),
                        Center(
                          child: Text(
                            'Fail',
                            style: TextStyle(fontSize: 14),
                          ),
                        ),
                        Center(
                          child: Text(
                            'Ticket can\'t be created as we are working\nfor your current ticket',
                            style: TextStyle(
                              fontSize: 14,
                            ),
                          ),
                        ),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(36),
                          child: Container(
                            width: 300,
                            child: RaisedButton(
                                color: Colors.blueAccent,
                                child: Text(
                                  'OK',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16),
                                ),
                                onPressed: () {
                                  if (status == 'fail') {
                                    setState(() {
                                      changePageIndex = 4;
                                      _animationController.reverse();
                                      isOpened = false;
                                    });
                                    Navigator.of(context).pop();
                                  } else {
                                    setState(() {
                                      changePageIndex = 5;
                                      _animationController.reverse();
                                      isOpened = false;
                                    });
                                    Navigator.of(context).pop();
                                  }
                                }),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ));
  }

  @override
  void dispose() {
    userIdController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  // setState(() {
  // changePageIndex = 5;
  // _animationController.reverse();
  // isOpened = false;
  // });
}
