import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:hiinternet/helpers/response_vo.dart';
import 'package:hiinternet/helpers/shared_pref.dart';
import 'package:hiinternet/screens/account_screen/account_bloc.dart';
import 'package:hiinternet/screens/account_screen/account_response.dart';
import 'package:hiinternet/screens/tabs_screen/tab_screen.dart';

class AccountScreen extends StatefulWidget {
  static const routeName = '/account_screen';

  @override
  _AccountScreenState createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  final _accountBloc = AccountBloc();
  var userId;

  @override
  void initState() {
    SharedPref.getData(key: SharedPref.user_id).then((value) {
      if (value != null && value.toString() != 'null') {
        userId = json.decode(value).toString();
        Map<String, String> map = {
          'user_id': userId,
          'app_version': '1',
        };
        _accountBloc.getAccountData(map);
      }
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          toolbarHeight: 110,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Container(
                  padding: EdgeInsets.all(10),
                  width: 100,
                  child: Image.asset(
                    'assets/images/hi_internet_logo.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ],
          ),
        ),
        body: SingleChildScrollView(
            padding: EdgeInsets.symmetric(vertical: 30),
            child: StreamBuilder<ResponseVO>(
              builder: (context, snapshot) {
                ResponseVO resp = snapshot.data;

                if (resp.message == MsgState.loading) {
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                }  else {
                  AccountVO accountOb = resp.data;
                  return Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        accountOb.name,
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Container(
                              padding: EdgeInsets.all(5),
                              child: Text(
                                'Active',
                                style:
                                    TextStyle(color: Colors.white, fontSize: 8),
                                textAlign: TextAlign.center,
                              ),
                              color: Colors.green,
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Container(
                                padding: EdgeInsets.all(5),
                                child: Text(
                                  accountOb.plan,
                                  style: TextStyle(
                                      color: Colors.white, fontSize: 8),
                                ),
                                color: Colors.indigo,
                              )),
                        ],
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border.all(color: Colors.grey),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        margin: EdgeInsets.all(10),
                        padding: EdgeInsets.all(10),
                        child: Column(
                          children: [
                            ListTile(
                              leading: CircleAvatar(
                                child:
                                    Icon(Icons.supervised_user_circle_rounded),
                              ),
                              title: Text('User ID'),
                              subtitle: Text(accountOb.userId),
                            ),
                            ListTile(
                              leading: CircleAvatar(
                                child: Icon(Icons.phone),
                              ),
                              title: Text('Phone Number'),
                              subtitle: Text(accountOb.mobileNo),
                            ),
                            ListTile(
                              leading: CircleAvatar(
                                child: Icon(Icons.date_range),
                              ),
                              title: Text('Activation Date'),
                              subtitle: accountOb.activateDate == null
                                  ? Text('---------')
                                  : Text(accountOb.activateDate),
                            ),
                            ListTile(
                              leading: CircleAvatar(
                                child: Icon(Icons.location_on),
                              ),
                              title: Text('Address'),
                              subtitle: Text(accountOb.address),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border.all(color: Colors.grey),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        margin: EdgeInsets.all(10),
                        padding: EdgeInsets.all(10),
                        width: 200,
                        child: InkWell(
                          onTap: () {
                            return showDialog(
                                context: context,
                                builder: (ctx) => Center(
                                      child: Container(
                                        height: 270,
                                        width: 230,
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          border:
                                              Border.all(color: Colors.grey),
                                          borderRadius:
                                              BorderRadius.circular(12),
                                        ),
                                        padding: EdgeInsets.all(4),
                                        child: Container(
                                          color: Colors.white,
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceAround,
                                            children: [
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.end,
                                                children: [
                                                  FlatButton(
                                                      onPressed: () {
                                                        Navigator.of(context)
                                                            .pop();
                                                      },
                                                      child: Icon(Icons
                                                          .cancel_presentation)),
                                                ],
                                              ),
                                              Text(
                                                'Logout',
                                                style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 18,
                                                    decoration:
                                                        TextDecoration.none,
                                                    color: Colors.black),
                                              ),
                                              SizedBox(
                                                height: 10,
                                              ),
                                              Text(
                                                'Do you want to logout\nthis application?',
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    decoration:
                                                        TextDecoration.none,
                                                    fontWeight:
                                                        FontWeight.normal,
                                                    fontSize: 14,
                                                    color: Colors.grey),
                                              ),
                                              SizedBox(
                                                height: 6,
                                              ),
                                              ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(28),
                                                child: RaisedButton(
                                                    color: Colors.blueAccent,
                                                    child: Text(
                                                      'LOGOUT',
                                                      style: TextStyle(
                                                          color: Colors.white,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 10),
                                                    ),
                                                    onPressed: () {
                                                      logout(context);
                                                    }),
                                              )
                                            ],
                                          ),
                                        ),
                                      ),
                                    ));
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.logout),
                              Text('sign out'),
                            ],
                          ),
                        ),
                      )
                    ],
                  );
                }
              },
              stream: _accountBloc.accountStream(),
              initialData: ResponseVO(message: MsgState.loading),
            )));
  }

  @override
  void dispose() {
    _accountBloc.dispose();
    super.dispose();
  }

  void logout(BuildContext context) {
    SharedPref.clear();
    Navigator.of(context).pop();
    Navigator.of(context).pushReplacementNamed(TabScreen.routeName);
  }
}
