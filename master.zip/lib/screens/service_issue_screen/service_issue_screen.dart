import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_neumorphic/flutter_neumorphic.dart';
import 'package:hiinternet/helpers/response_vo.dart';
import 'package:hiinternet/helpers/shared_pref.dart';
import 'package:hiinternet/screens/service_history_screen/service_history_screen.dart';
import 'package:hiinternet/screens/service_issue_screen/send_service_issue_complain_bloc.dart';
import 'package:hiinternet/screens/service_issue_screen/service_complain_response.dart';
import 'package:hiinternet/screens/service_issue_screen/service_issue_bloc.dart';
import 'package:hiinternet/screens/service_issue_screen/service_issue_response.dart';

class ServiceIssueScreen extends StatefulWidget {
  static const routeName = '/service_issue';

  @override
  _ServiceIssueScreenState createState() => _ServiceIssueScreenState();
}

class _ServiceIssueScreenState extends State<ServiceIssueScreen> {
  var selectedCategoryId;
  var phoneController = TextEditingController(text: "09xxxxxxx");

  final _serviceIssueBloc = ServiceIssueBloc();
  final _serviceComplainBloc = SendServiceComplainBloc();
  int changePageIndex = 0;
  var userId;


  @override
  void initState() {
    changePageIndex = 0;


    SharedPref.getData(key: SharedPref.user_id).then((value) {
      if (value != null && value.toString() != 'null') {
        userId = json.decode(value).toString();
        Map<String, String> map = {
          'user_id': userId,
          'app_version': '1',
        };

        _serviceIssueBloc.getServiceIssueCategory(map);
        print(userId);
      }
    });



    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return changePageIndex == 1
        ? ServiceHistoryScreen()
        : Scaffold(
            appBar: AppBar(
              automaticallyImplyLeading: false,
              toolbarHeight: 90,
              title: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Container(
                      padding: EdgeInsets.all(15),
                      width: 100,
                      child: Image.asset(
                        'assets/images/hi_internet_logo.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            body: Center(
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: 400,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      margin: EdgeInsets.all(10),
                      padding: EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Service Ticket',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.indigo,
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.all(20),
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.all(10),
                                      child: Icon(Icons.phone),
                                    ),
                                    Expanded(
                                      child: Padding(
                                          padding:
                                              const EdgeInsets.only(left: 12),
                                          child: TextField(
                                            controller: phoneController,
                                          )),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Row(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.all(10),
                                      child: Icon(Icons.category),
                                    ),
                                    StreamBuilder<ResponseVO>(
                                        stream: _serviceIssueBloc
                                            .serviceIssueStream(),
                                        initialData: ResponseVO(
                                            message: MsgState.loading),
                                        builder: (context, snapshot) {
                                          ResponseVO resp = snapshot.data;
                                          if (resp.message ==
                                              MsgState.loading) {
                                            return Center(
                                              child: Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 100),
                                                child:
                                                    CircularProgressIndicator(
                                                  strokeWidth: 3,
                                                ),
                                              ),
                                            );
                                          } else if (resp.message ==
                                              MsgState.error) {
                                            return Center(
                                              child: Text(
                                                  'Something wrong,try again...'),
                                            );
                                          } else {
                                            List<CategoryVO> list = resp.data;

                                            return Flexible(
                                              child: Container(
                                                padding:
                                                    EdgeInsets.only(left: 10),
                                                width: MediaQuery.of(context)
                                                    .size
                                                    .width,
                                                child: ButtonTheme(
                                                  alignedDropdown: true,
                                                  child:
                                                      DropdownButtonFormField<
                                                          int>(
                                                    onChanged: (value) {
                                                      selectedCategoryId =
                                                          value;
                                                    },
                                                    items: list.map((data) {
                                                      return DropdownMenuItem(
                                                        child: Text(data.name),
                                                        value: data.id,
                                                      );
                                                    }).toList(),
                                                    hint: Text(
                                                        '--Select Category--'),
                                                  ),
                                                ),
                                              ),
                                            );
                                          }
                                        }),
                                  ],
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Container(
                                  alignment: Alignment.topLeft,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(color: Colors.grey),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  padding: EdgeInsets.all(30),
                                  child: Form(
                                      child: TextFormField(
                                    textAlign: TextAlign.left,
                                    decoration: InputDecoration(
                                        border: InputBorder.none,
                                        focusedBorder: InputBorder.none,
                                        enabledBorder: InputBorder.none,
                                        errorBorder: InputBorder.none,
                                        disabledBorder: InputBorder.none,
                                        hintText:
                                            "Describe more about your problem",
                                        hintStyle: TextStyle(fontSize: 14)),
                                  )),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                sendComplainButton(context),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
  }

  // ignore: missing_return
  Future showStatusDialog(BuildContext context, String status,String ticketID) async {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await showDialog(
          context: context,
          builder: (ctx) => Center(
                child: Container(
                  height: 300,
                  width: double.infinity,
                  margin: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  padding: EdgeInsets.all(4),
                  child: Material(
                    child: Container(
                      color: Colors.white,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Center(
                            child: Text(status),
                          ),

                          Center(
                            child: Text( '${'Your ticket ID is '}$ticketID' ),
                          ),

                          ClipRRect(
                            borderRadius: BorderRadius.circular(36),
                            child: Container(
                              width: 300,
                              child: RaisedButton(
                                  color: Colors.blueAccent,
                                  child: Text(
                                    'OK',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16),
                                  ),
                                  onPressed: () {
                                    if (status == 'Fail') {
                                      setState(() {
                                        changePageIndex = 1;
                                      });
                                      Navigator.of(context).pop();
                                    } else if (status == 'Success') {
                                      setState(() {
                                        changePageIndex = 1;
                                      });
                                    }
                                  }),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ));
    });
  }

  Widget sendComplainButton(BuildContext context) {
    return StreamBuilder<ResponseVO>(
      initialData: ResponseVO(),
      stream: _serviceComplainBloc.serviceComplainStream(),
      builder: (context, snapshot) {
        ResponseVO resp = snapshot.data;
        if (resp.message == MsgState.loading) {
          return Center(
            child: CircularProgressIndicator(
              strokeWidth: 3,
            ),
          );
        } else if (resp.message == MsgState.success) {
          ServiceComplainResponseVO serviceComplainResponseVO = resp.data;

          showStatusDialog(context, 'Well Received',serviceComplainResponseVO.ticketId);

          return Center();
        } else if (resp.message == MsgState.error) {
          ServiceComplainResponseVO serviceComplainResponseVO = resp.data;

          showStatusDialog(context, 'Fail','11111112222');
          return Center();
        } else {
          return ClipRRect(
            borderRadius: BorderRadius.circular(36),
            child: Container(
              width: 500,
              child: RaisedButton(
                  color: Colors.blueAccent,
                  child: Text(
                    'Send',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16),
                  ),
                  onPressed: () {
                    sendServiceComplain();
                  }),
            ),
          );
        }
      },
    );
  }

  void sendServiceComplain() {
    Map<String, String> map = {
      'user_id': userId,
      'app_version': '1',
      'phone': '099999999',
      'description': 'No internet',
      'category': 'ffff',
    };

    _serviceComplainBloc.sendServiceComplain(map);
  }

  @override
  void dispose() {
    _serviceIssueBloc.dispose();
    _serviceComplainBloc.dispose();
    super.dispose();
  }
}
